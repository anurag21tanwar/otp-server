TWO ENTITIES:
USERS, OTPS

ASSOCIATIONS:
USERS has_many opts

ROUTING:

users/:id/opts/generate
users/:id/opts/verify/:code

EXCEPTION HANDLING:

STANDARD-ERROR 500
OPT INVALID 400

