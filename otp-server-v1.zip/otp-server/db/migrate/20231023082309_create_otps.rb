class CreateOtps < ActiveRecord::Migration[7.1]
  def change
    create_table :otps do |t|
      t.string :code
      t.string :user_id
      t.boolean :is_verified, default: false

      t.timestamps

      t.index :code
    end
  end
end
