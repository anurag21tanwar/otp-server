FactoryBot.define do
  factory :otp do
    trait :verified do
      is_verified { true }
    end
  end
end
