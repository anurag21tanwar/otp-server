FactoryBot.define do
  factory :user do
    phone_number { rand.to_s[2..10] }
  end
end
