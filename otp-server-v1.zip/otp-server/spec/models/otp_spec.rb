require 'rails_helper'

RSpec.describe Otp, type: :model do
end
