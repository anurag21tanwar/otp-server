require 'rails_helper'

RSpec.describe "/users", type: :request do
end
