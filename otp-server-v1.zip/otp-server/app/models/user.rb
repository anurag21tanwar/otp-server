class User < ApplicationRecord
  has_many :otps

  # validates :phone_number, length: { is: 8 }
end
