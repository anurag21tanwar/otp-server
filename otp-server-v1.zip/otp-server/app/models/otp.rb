class Otp < ApplicationRecord
  CODE_LENGTH = 6
  CODE_LIVE_TILL = 1.minute

  belongs_to :user

  validates :code, length: { is: CODE_LENGTH }

  before_validation :generate_code

  def verify!
    update!(is_verified: true)
  end

  def expired?
    is_verified || Time.zone.now <= created_at + CODE_LIVE_TILL
  end

  private

  def generate_code
    base = 2
    self.code ||= rand.to_s[base...(CODE_LENGTH+base)]
  end
end
