module Api
  module V1
    class OtpsController < ApplicationController
      def generate
        OtpService.new(params[:id]).generate
        render status: :ok, json: {}
      end

      def verify
        msg = OtpService.new(params[:id]).verify(params[:code])
        render status: :ok, json: { message: msg }
      end
    end
  end
  end

