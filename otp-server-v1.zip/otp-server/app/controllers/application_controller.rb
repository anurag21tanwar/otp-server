# frozen_string_literal: true

class ApplicationController < ActionController::API
  rescue_from StandardError, with: :show_internal_error

  private

  def show_internal_error(exception)
    render status: :internal_server_error, json: error_message(exception)
  end

  def error_message(exception)
    { errors: { message: exception.message } }
  end
end
