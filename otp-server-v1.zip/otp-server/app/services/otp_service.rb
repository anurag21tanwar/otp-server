class OtpService
  attr_reader :user

  def initialize(user_id)
    @user = User.find(user_id)
  end

  def generate
    user.otps.create!
  rescue ActiveRecord::Validations
    raise ActiveRecord::RecordInvalid
  end

  def verify(code)
    code = user.otps.find_by(code: code)
    raise ActiveRecord::RecordNotFound unless code
    raise ActiveRecord::RecordInvalid if code.expired?

    code.verify!
  end
end