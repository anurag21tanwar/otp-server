module Errors
  module Otp
    class Expired < StandardError
    end
  end
end