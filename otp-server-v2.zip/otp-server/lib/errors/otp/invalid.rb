module Errors
  module Otp
    class Invalid < StandardError
    end
  end
end