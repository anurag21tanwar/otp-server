module Errors
  module Otp
    class NotFound < StandardError
    end
  end
end