# frozen_string_literal: true

class OtpService
  attr_reader :user

  def initialize(user_id)
    @user = User.find(user_id)
  end

  def generate
    otp = user.otps.create!
    otp.code
  rescue ActiveRecord::Validations
    raise Errors::Otp::Invalid
  end

  def verify(code)
    code = user.otps.find_by(code: code)
    raise Errors::Otp::NotFound unless code
    raise Errors::Otp::Expired if code.expired?

    code.verify! && true
  end
end
