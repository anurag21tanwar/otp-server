# frozen_string_literal: true

class User < ApplicationRecord
  PHONE_LENGTH = 8

  has_many :otps

  validates :phone_number, length: { is: PHONE_LENGTH }
end
