# frozen_string_literal: true

class Otp < ApplicationRecord
  CODE_LENGTH = 6
  CODE_LIVE_TILL = 1.minute

  belongs_to :user

  validates :code, length: { is: CODE_LENGTH }
  validates :code, uniqueness: { scope: :user_id }

  before_validation :generate_code
  after_create :send_sms

  def verify!
    update!(is_verified: true)
  end

  def expired?
    is_verified || Time.zone.now > created_at + CODE_LIVE_TILL
  end

  private

  def generate_code
    base = 2
    self.code ||= rand.to_s[base...(CODE_LENGTH + base)]
  end

  def send_sms
    # back ground job for sms
  end
end
