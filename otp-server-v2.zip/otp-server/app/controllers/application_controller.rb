# frozen_string_literal: true

class ApplicationController < ActionController::API
  rescue_from StandardError, with: :show_internal_error
  rescue_from Errors::Otp::Invalid, with: :show_invalid_error
  rescue_from Errors::Otp::Expired, with: :show_invalid_error
  rescue_from Errors::Otp::NotFound, with: :show_not_found

  private

  def show_internal_error(exception)
    render status: :internal_server_error, json: error_message(exception)
  end

  def show_invalid_error(exception)
    render status: :bad_request, json: error_message(exception)
  end

  def show_not_found(exception)
    render status: :not_found, json: error_message(exception)
  end

  def error_message(exception)
    { errors: { message: exception.message } }
  end
end
