# frozen_string_literal: true

module Api
  module V1
    class OtpsController < ApplicationController
      def generate
        code = OtpService.new(params[:user_id]).generate
        render status: :ok, json: { code: code }
      end

      def verify
        status = OtpService.new(params[:user_id]).verify(params[:code])
        render status: :ok, json: { status: status }
      end
    end
  end
end
