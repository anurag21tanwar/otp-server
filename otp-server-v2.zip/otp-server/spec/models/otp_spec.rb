# frozen_string_literal: true

require 'rails_helper'
RSpec.describe Otp, type: :model do
  let(:user) { create(:user) }
  subject { build(:otp, user: user) }

  it 'is valid' do
    is_expected.to be_valid
  end

  describe '.validations' do
    it { is_expected.to validate_length_of(:code).is_equal_to(Otp::CODE_LENGTH) }
  end

  describe '#expired?' do
    subject { create(:otp, user: user) }

    context 'when code is alive' do
      it 'returns false' do
        expect(subject.expired?).to be(false)
      end
    end

    context 'when code is expired' do
      it 'returns true' do
        otp = subject
        travel 1.day
        expect(otp.expired?).to be(true)
      end
    end

    context 'when code verified already' do
      subject { create(:otp, :verified, user: user) }

      it 'returns true' do
        expect(subject.expired?).to be(true)
      end
    end
  end

  describe '#verify!' do
    it 'before' do
      expect(subject.is_verified?).to be(false)
    end

    it 'after call is_verified is true' do
      subject.verify!
      expect(subject.is_verified?).to be(true)
    end
  end
end
