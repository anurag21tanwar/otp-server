# frozen_string_literal: true

require 'rails_helper'

RSpec.describe '/users/:id/opts', type: :request do
  let(:user) { create(:user) }

  describe 'GET api/v1/users/:id/opts/generate' do
    before { get otps_generate_api_v1_user_path(user) }

    it 'renders a successful response' do
      expect(response).to be_successful
    end

    it 'renders a successful response body' do
      expect(response.body).to eq({"code": user.otps.last.code}.to_json)
    end
  end

  describe 'GET api/v1/users/:id/otps/verify/:code' do
    let(:otp) { create(:otp, user: user) }

    before { get otps_verify_api_v1_user_path(user, code: otp.code) }

    it 'renders a successful response' do
      expect(response).to be_successful
    end

    it 'renders a successful response body' do
      expect(response.body).to eq({"status": true}.to_json)
    end

    context 'when code verified already' do
      let(:otp) { create(:otp, :verified, user: user) }

      it 'bad request status' do
        expect(response.status).to eq(400)
      end

      it 'renders a bad request response body' do
        expect(response.body).to eq({ "errors": { "message": 'Errors::Otp::Expired' } }.to_json)
      end
    end

    context 'when code not found' do
      let(:otp) { OpenStruct.new(code: '123', user: user) }

      it 'not found request status' do
        expect(response.status).to eq(404)
      end

      it 'renders a bad request response body' do
        expect(response.body).to eq({ "errors": { "message": 'Errors::Otp::NotFound' } }.to_json)
      end
    end
  end
end
