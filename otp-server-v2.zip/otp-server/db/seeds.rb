# frozen_string_literal: true
5.times { FactoryBot.create(:user) }
