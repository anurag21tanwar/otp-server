# frozen_string_literal: true

Rails.application.routes.draw do
  namespace :api do
    namespace :v1 do
      resources :users, param: :user_id do
        member do
          scope :opts do
            get 'generate', to: 'otps#generate', as: :otps_generate
            get 'verify/:code', to: 'otps#verify', as: :otps_verify
          end
        end
      end
    end
  end
  get 'up' => 'rails/health#show', as: :rails_health_check
end
