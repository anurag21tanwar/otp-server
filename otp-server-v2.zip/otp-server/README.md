### Resources:
- USERS
- OTPS

### Associations:
- users has_many opts

### Routing:
- api/v1/users/:id/opts/generate
- api/v1/users/:id/opts/verify/:code

### Seed DB
- rails db:reset db:setup

### Rspec
- bundle exec rspec

### Code Coverage
- 97%
- tmp/coverage/index.html

### Postman
- http://127.0.0.1:3000/api/v1/users/:id/opts/generate [tmp/assets/generate.png]
- http://127.0.0.1:3000/api/v1/users/:id/opts/verify/:code [tmp/assets/verify.png]


